#!/bin/bash

sddm-greeter --test-mode --theme .
